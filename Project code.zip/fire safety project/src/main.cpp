#define BLYNK_TEMPLATE_ID "TMPL6nbwelbce"
#define BLYNK_TEMPLATE_NAME "Fire Safety and Automatic Water Response system"
#define BLYNK_AUTH_TOKEN "h6Nzt1LTNGvpYd2vUGaioY0mtJnsH4Kx"

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>

// ----------- WiFi Credentials -----------
char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "YOUR_WIFI_SSID";
char pass[] = "YOUR_WIFI_PASSWORD";

// ----------- PINS -----------
#define DHT_PIN     14
#define DHT_TYPE    DHT11
#define FLAME_PIN   25
#define MQ2_PIN     34
#define BUZZER_PIN  26   // UPDATED
#define RELAY_PIN   27   // UPDATED

// ----------- THRESHOLD -----------
#define SMOKE_THRESHOLD 2800

DHT dht(DHT_PIN, DHT_TYPE);

unsigned long startTime;
unsigned long lastBeepTime = 0;
bool flameAlertSent = false;
bool buzzerState = false;

// ----------- FLAME CONFIRMATION -----------
bool confirmFlame() {
  int detectCount = 0;
  for (int i = 0; i < 5; i++) {
    if (digitalRead(FLAME_PIN) == LOW) detectCount++;
    delay(10);
  }
  return (detectCount >= 4);
}

void setup() {
  Serial.begin(115200);
  startTime = millis();

  pinMode(FLAME_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RELAY_PIN, LOW);

  dht.begin();
  Blynk.begin(auth, ssid, pass);
}

void loop() {
  Blynk.run();

  float temperature = dht.readTemperature();
  float humidity    = dht.readHumidity();
  int smokeRaw      = analogRead(MQ2_PIN);

  if (isnan(temperature)) temperature = 0;
  if (isnan(humidity)) humidity = 0;

  bool mq2Ready = (millis() - startTime > 30000);
  bool smokeDetected = mq2Ready && (smokeRaw > SMOKE_THRESHOLD);
  bool flameDetected = confirmFlame();

  Serial.printf("Temp: %.1f | Hum: %.1f | Smoke: %d | Flame: %s\n",
                temperature, humidity, smokeRaw,
                flameDetected ? "YES" : "NO");

  // ----------- BUZZER (ONLY REAL FLAME) -----------
  if (flameDetected) {
    if (millis() - lastBeepTime >= 600) {
      buzzerState = !buzzerState;
      digitalWrite(BUZZER_PIN, buzzerState);
      lastBeepTime = millis();
    }
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }

  // ----------- RELAY + MOTOR -----------
  if (flameDetected || smokeDetected) {
    digitalWrite(RELAY_PIN, HIGH);
  } else {
    digitalWrite(RELAY_PIN, LOW);
  }

  // ----------- BLYNK UPDATE -----------
  Blynk.virtualWrite(V1, temperature);
  Blynk.virtualWrite(V2, humidity);
  Blynk.virtualWrite(V3, flameDetected ? 255 : 0);
  Blynk.virtualWrite(V4, smokeRaw);
  Blynk.virtualWrite(V5, smokeDetected ? 255 : 0);

  // ----------- BLYNK ALERT -----------
  if (flameDetected && !flameAlertSent) {
    Blynk.logEvent("fire_alert", "🔥 Fire Detected! Pump Activated!");
    flameAlertSent = true;
  }
  if (!flameDetected) flameAlertSent = false;

  delay(300);
}
